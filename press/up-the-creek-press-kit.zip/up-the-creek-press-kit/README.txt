Up the Creek! press kit
Serious Soup · press@serioussoup.com · https://serioussoup.com/press/

Everything here is free to use in articles, videos and streams about the game.
Steam: https://store.steampowered.com/app/5595130/
